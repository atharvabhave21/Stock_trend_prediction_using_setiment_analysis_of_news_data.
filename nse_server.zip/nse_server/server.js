var express = require('express');
var fs = require('fs');
var util = require('util');
var app = express();
var http = require('http').Server(app);
var logger = require("./utils/logger");
var io = require('socket.io')(http);
var tmpSocket = require("./socket.js");
tmpSocket.initializeSocket(io);
var tempmqtt = require('mqtt')
var mqtt = require('./mqtt.js');
var client = mqtt.mqttConnect(tempmqtt);
//var MongoClient = require('mongodb').MongoClient;
//var url = "mongodb://127.0.0.1:27017/mydb";
var utils;

app.get('/', function(req, res) {
	console.log("request made");
	res.sendfile('./staticpages/index.html');
});
app.get('/trading.html', function(req, res) {
	console.log("request made");
	res.sendfile('./staticpages/trading.html');
});
app.get('/chart.html', function(req, res) {
	console.log("request made");
	res.sendfile('./staticpages/chart3.html');
});
app.get('/chart3.html', function(req, res) {
	console.log("request made");
	res.sendfile('./staticpages/chart3.html');
});

app.post('/form',function(req,res){
	req.on('data', function(chunk) {
		var textChunk = chunk.toString('utf8');
        console.log(textChunk);

	});

	res.send('Successfully Sent');
});

app.get('/download',function(req,res){
 	logger.info('File Downloading');
	var file = './netflix-stock-price.txt';
		fs.exists(file, function(exists) {
  			if (exists) {
  var filename = 'netflix-stock-price.txt'

  res.setHeader('Content-disposition', 'attachment; filename=' + filename);
  res.setHeader('Content-type', 'txt');

  var filestream = fs.createReadStream(file);
  filestream.pipe(res);
  	}
	});
		//res.write("Done Downloading");
});
app.get('/download/pnb',function(req,res){
 	logger.info('File Downloading');
	var file = './public/data/PNB_stocks.txt';
		fs.exists(file, function(exists) {
  			if (exists) {
  var filename = 'PNB_stocks.txt'

  res.setHeader('Content-disposition', 'attachment; filename=' + filename);
  res.setHeader('Content-type', 'text');

  var filestream = fs.createReadStream(file);
  filestream.pipe(res);
  	}
	});
		//res.write("Done Downloading");
});
app.get('/download/AXISBANK',function(req,res){
 	logger.info('File Downloading');
	var file = './public/data/AXISBANK_stocks.txt';
		fs.exists(file, function(exists) {
  			if (exists) {
  var filename = 'AXISBANK_stocks.txt'

  res.setHeader('Content-disposition', 'attachment; filename=' + filename);
  res.setHeader('Content-type', 'text');

  var filestream = fs.createReadStream(file);
  filestream.pipe(res);
  	}
	});
		//res.write("Done Downloading");
});
app.get('/download/INFY',function(req,res){
 	logger.info('File Downloading');
	var file = './public/data/INFY_stocks.txt';
		fs.exists(file, function(exists) {
  			if (exists) {
  var filename = 'INFY_stocks.txt'

  res.setHeader('Content-disposition', 'attachment; filename=' + filename);
  res.setHeader('Content-type', 'text');

  var filestream = fs.createReadStream(file);
  filestream.pipe(res);
  	}
	});
		//res.write("Done Downloading");
});
app.get('/download/TATASTEEL',function(req,res){
 	logger.info('File Downloading');
	var file = './public/data/TATASTEEL_stocks.txt';
		fs.exists(file, function(exists) {
  			if (exists) {
  var filename = 'TATASTEEL_stocks.txt'

  res.setHeader('Content-disposition', 'attachment; filename=' + filename);
  res.setHeader('Content-type', 'text');

  var filestream = fs.createReadStream(file);
  filestream.pipe(res);
  	}
	});
		//res.write("Done Downloading");
});
app.get('/download/WIPRO',function(req,res){
 	logger.info('File Downloading');
	var file = './public/data/WIPRO_stocks.txt';
		fs.exists(file, function(exists) {
  			if (exists) {
  var filename = 'WIPRO_stocks.txt'

  res.setHeader('Content-disposition', 'attachment; filename=' + filename);
  res.setHeader('Content-type', 'text');

  var filestream = fs.createReadStream(file);
  filestream.pipe(res);
  	}
	});
		//res.write("Done Downloading");
});
http.listen(443,function(){
	logger.info("Signallng server is listening on port 443");
});
