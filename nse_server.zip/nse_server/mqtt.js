
exports.mqttConnect = function(mqtt){
    var client  = mqtt.connect('mqtt://13.126.45.185')
    client.on('connect', function () {
        console.log("Connected to remote broker successfully")
        })
        return client
}

exports.mqtt_pub = function(client,payload){
var body = JSON.parse(payload);
    client.publish(body.topic,'{"nse_symbol":"'+body.nse_symbol+'","qty":"'+body.qty+'"}')
    console.log("'"+body.topic+"'"+","+ '{"nse_symbol":"'+body.nse_symbol+'","qty":"'+body.qty+'"}');
}

exports.mqtt_sub = function(client,topic){
    client.subscribe(topic)
    console.log("Successfully subscribed to topic '"+topic+"'");
}

exports.payload = function(client){

    client.on('message', function (topic, message) {
      // message is Buffer
      console.log(topic.toString()+':'+message.toString())


     client.end()
      console.log('After return')
    })
}
