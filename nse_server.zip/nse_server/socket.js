var logger = require("./utils/logger");
var tempmqtt = require('mqtt')
var mqtt = require('./mqtt.js');
var client = mqtt.mqttConnect(tempmqtt);

//var assert = require('assert');
//var socketUtil = require('./CommonSocketUtils.js');
//var coll; // db collection
var namespaceMap = {};
var socketIo;
var callReceivedCount = 0;
//var MONGODB_URI = 'mongodb://127.0.0.1:27017/mydb';
//var db; // create db connection pool
var userNameSocketMap = {};

mqtt.mqtt_sub(client,'nse_action');

exports.initializeSocket = function (io) {
	socketIo = io;
	io.of("/").on('connect', function (socket) {

	    logger.info("a user connected to default namespace");
				var defaultNamespace = io.of('/');
        var defaultSocket = socket;
			socket.on('symbol', function (message, callback) {

				var client = mqtt.mqttConnect(tempmqtt);
						mqtt.mqtt_sub(client,'nse_action');
						mqtt.mqtt_pub(client,'{"topic":"nse_symbol","nse_symbol":"'+ message.symbol+'","qty":"'+message.qty+'"}');
						mqtt.payload(client);
						console.log(message);
		});
		var client = mqtt.mqttConnect(tempmqtt);
		mqtt.mqtt_sub(client,'nse_action');
		client.on('message', function (topic, message) {
			// message is Buffer
			console.log(topic.toString()+':'+message.toString())
			var message = message.toString();
					socket.emit('result', message);
		});

});
};
